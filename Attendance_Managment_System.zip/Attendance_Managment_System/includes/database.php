<?php

class DATABASE
{
	protected $username 	= NULL;
	protected $password 	= NULL;
	protected $host 		= NULL;
	protected $databse 		= NULL;
	protected $query 		= NULL;
	protected $result 		= NULL;
	protected $result2 		= NULL;

	function __construct(){

		$this->username 	= 'root';
		$this->host 		= 'localhost';
		$this->databse 		= 'attendance_managment_system';
		$this->password		= '';
		$this->connection 	= mysqli_connect($this->host, $this->username, $this->password, $this->databse);
		if(mysqli_connect_errno()){
			echo "database error";
		}	
	}
	public function register_user($first_name, $last_name, $email, $gender,$file_name, $password){
		$this->query = "INSERT INTO users (first_name, last_name, gender, email,profile_picture,PASSWORD, created_at) VALUES('".$first_name."','".$last_name."','".$gender."','".$email."','".$file_name."','".$password."', CURDATE())";
		$this->result = mysqli_query($this->connection, $this->query);
		return $this->result;
	}
	public function user_check($email, $password){
		$this->query 	= "SELECT * FROM users WHERE email = '".$email."' AND PASSWORD = '".$password."'";
		$this->result 	= mysqli_query($this->connection, $this->query);
		return $this->result;
	}
	public function check_email($email){
		$this->query 	= "SELECT * FROM users WHERE email = ".$email." ";
		$this->result 	= mysqli_query($this->connection, $this->query);
		$this->result2 	= mysqli_fetch_assoc($this->result);
		return $this->result2;
	}
	public function place_attendance($user_id,$date){
		$this->query = "INSERT INTO attendance (user_id,a_status_id, attendance_date) VALUES('".$user_id."',2,'".$date."')";
		$this->result = mysqli_query($this->connection, $this->query);
		return $this->result;
	}
	public function update_attendance($user_id,$date){
		$this->query = "UPDATE attendance 
						SET a_status_id = 1	
						WHERE attendance.`user_id`  = '".$user_id."'
						AND attendance.`attendance_date` = '".$date."'";
		$this->result = mysqli_query($this->connection, $this->query);
		return $this->result;
	}
	public function check_attendance($user_id,$date){
		$this->query = "SELECT * FROM attendance WHERE user_id = '".$user_id."' AND attendance_date = '".$date."' AND a_status_id = 1 ";
		$this->result = mysqli_query($this->connection, $this->query);
		return $this->result;
	}
	public function check_date($date){
		$this->query = "SELECT * FROM attendance WHERE attendance_date = '".$date."'";
		$this->result = mysqli_query($this->connection, $this->query);
		return $this->result;
	}
	public function save_application($application_title,$application_description,$user_id,$date){
		$this->query = "INSERT INTO applications (application_title, application_description, user_id, created_at) VALUES('".$application_title."', '".$application_description."', '".$user_id."','".$date."')";
		$this->result = mysqli_query($this->connection, $this->query);
		return $this->result;

	}
	public function update_user_profile($user_id,$file_name){
		$this->query = "UPDATE users SET profile_picture = '".$file_name."' WHERE user_id = '".$user_id."' ";
		$this->result = mysqli_query($this->connection, $this->query);
		return $this->result;
	}
	public function get_user_data($user_id){
		$this->query = "SELECT * FROM attendance, a_status 
				WHERE a_status.`a_status_id` = attendance.`a_status_id`
				AND attendance.`user_id` = '".$user_id."' ORDER BY(attendance.`attendance_id`) DESC";
		$this->result = mysqli_query($this->connection, $this->query);
		return $this->result;
	}
	public function get_user_info($user_id){
		$this->query = "SELECT * FROM users where user_id = '".$user_id."' ";
		$this->result = mysqli_query($this->connection, $this->query);
		return $this->result;
	}
	public function get_all_users(){
		$this->query = "SELECT * FROM users where role_id = 1";
		$this->result = mysqli_query($this->connection, $this->query);
		return $this->result;
	}
	public function user_report($start_date,$end_date,$user_id){
		$this->query = "SELECT * FROM attendance, a_status 
					WHERE a_status.`a_status_id` = attendance.`a_status_id`
					AND attendance.`attendance_date` >= '".$start_date."'
					AND attendance.`attendance_date` <= '".$end_date."'
					AND attendance.`user_id` = '".$user_id."' ORDER BY(attendance.`attendance_id`) DESC";
		$this->result = mysqli_query($this->connection, $this->query);
		return $this->result;	
	}
	public function users_report($start_date,$end_date){
		$this->query = "SELECT * FROM users,attendance,a_status
					WHERE users.`user_id` = attendance.`user_id`
					AND attendance.`a_status_id` = a_status.`a_status_id`
					AND attendance.`attendance_date` >= '".$start_date."'
					AND attendance.`attendance_date` <= '".$end_date."'
					ORDER BY (attendance.`attendance_id`) DESC";
		$this->result = mysqli_query($this->connection, $this->query);
		return $this->result;	
	}
	public function get_users_data(){
		$this->query = "SELECT * FROM users, attendance, a_status
			WHERE users.`user_id` = attendance.`user_id`
			AND attendance.`a_status_id` = a_status.`a_status_id`";
		$this->result = mysqli_query($this->connection, $this->query);
		return $this->result;
	}
	public function get_status(){
		$this->query = "SELECT * FROM a_status";
		$this->result = mysqli_query($this->connection, $this->query);
		return $this->result;
	}
	public function update_status($user_id,$status_id,$attendance_date){
		$this->query = "UPDATE attendance
						SET a_status_id = ".$status_id."
						WHERE user_id = ".$user_id." 
						AND attendance_date = ".$attendance_date." ";
		$this->result = mysqli_query($this->connection, $this->query);
		return $this->result;
	}
	public function save_login_time($user_id,$login_time){
		$this->query = "INSERT INTO activity_log (user_id,login_time) VALUES('".$user_id."', '".$login_time."')";
		$this->result = mysqli_query($this->connection, $this->query);
		return $this->result;
	}
	public function save_logout_time($user_id,$logout_time){
		$this->query = "UPDATE activity_log 
						SET logout_time = '".$logout_time."'	
						WHERE user_id = '".$user_id."' ";
		$this->result = mysqli_query($this->connection, $this->query);
		return $this->result;
	}
	public function get_applications(){
		$this->query = "SELECT users.`user_id`, users.`first_name`, users.`last_name`, users.`email`, applications.`created_at` FROM users, applications, a_status
			WHERE users.`user_id` = applications.`user_id`
			AND applications.`a_status_id` = a_status.`a_status_id`
			AND applications.`a_status_id` = 4";
		$this->result = mysqli_query($this->connection, $this->query);
		return $this->result;
	}
	public function approve_application($user_id,$created_at){
		$this->query = "UPDATE applications
						SET a_status_id = 5
						WHERE user_id = '".$user_id."'
						AND created_at = '".$created_at."' ";
		$this->result = mysqli_query($this->connection, $this->query);
		return $this->result;
	}
	public function update_user_attendance($user_id,$created_at){
		$this->query = "UPDATE attendance 
						SET a_status_id = 3
						WHERE user_id = '".$user_id."'
						AND attendance_date = '".$created_at."' ";
		$this->result = mysqli_query($this->connection, $this->query);
		return $this->result;
	}
	public function get_user_application($user_id,$created_at){
		$this->query = "SELECT * FROM applications 
						WHERE user_id = '".$user_id."'
						AND created_at = '".$created_at."'";
		$this->result = mysqli_query($this->connection, $this->query);
		return $this->result;
	}
	public function get_activity_log(){
		$this->query = "SELECT * FROM users,activity_log 
						WHERE users.`user_id` = activity_log.`user_id` 
						AND logout_time IS NULL";
		$this->result = mysqli_query($this->connection, $this->query);
		return $this->result;
	}

}



?>