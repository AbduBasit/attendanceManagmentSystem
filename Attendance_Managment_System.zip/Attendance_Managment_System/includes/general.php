<?php

class GENERAL_HTML
{
	public function header($title,$css_link){ ?>
		<!DOCTYPE html>
		<html lang="en">
		<head>
		    <meta charset="UTF-8">
		    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		    <meta name="description" content="au theme template">
		    <meta name="author" content="Hau Nguyen">
		    <meta name="keywords" content="au theme template">
		    <title><?php echo $title?></title>
		    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
		    <!-- Main CSS-->
		    <link href="<?php echo $css_link?>" rel="stylesheet" media="all">
		    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css"/>
		    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/datetime/1.1.0/css/dataTables.dateTime.min.css"/>
		    

		</head>
	<?php
	}

	public function footer(){ ?>
			</body>
			<script type="text/javascript" src="js/jquery-3.5.1.js"></script>
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
			  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
			<script type="text/javascript" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
			<script type="text/javascript" src="https://cdn.datatables.net/datetime/1.1.0/js/dataTables.dateTime.min.js"></script>
			<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
			
			
			
			
			  
			  <script type="text/javascript" src = "js/script.js"></script>

	</html>
	<?php
	}
	public function login_page(){ ?>
		<body class="animsition">
		    <div class="page-wrapper">
		        <div class="page-content--bge5">
		            <div class="container">
		                <div class="login-wrap">
		                    <div class="login-content">
		                        <div class="login-logo">
		                                <img src="images/icon/login.png" alt="LogIn">
		                        </div>
		                        <?php
		                        if(isset($_REQUEST['message'])){ ?>
		                        <div class="alert alert-danger alert-dismissible">
								    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
								    <?php echo $_REQUEST['message']?>
								  </div>
		                        <?php
		                        }
		                        ?>
		                        <div class="login-form">
		                            <form action="process.php" method="post">
		                                <div class="form-group">
		                                    <label>Email Address</label>
		                                    <input class="au-input au-input--full" type="email" name="email" placeholder="Email" required>
		                                </div>
		                                <div class="form-group">
		                                    <label>Password</label>
		                                    <input class="au-input au-input--full" type="password" name="password" placeholder="Password" required>
		                                </div>
		                                <br>
		                                <input class="au-btn au-btn--block au-btn--green m-b-20" type="submit" value="login" name="login">
		                                
		                            </form>
		                            <div class="register-link">
		                                <p>
		                                    Don't you have account?
		                                    <a href="register.php">Sign Up Here</a>
		                                </p>
		                            </div>
		                        </div>
		                    </div>
		                </div>
		            </div>
		        </div>
		    </div>
	<?php
	}
	public function register_page(){ 
		?>
		<body class="animsition">
		    <div class="page-wrapper">
		        <div class="">
		            <div class="container">
		                <div class="login-wrap">
		                    <div class="login-content">
		                        <div class="login-logo">
		                                <img src="images/icon/register.png" alt="Register">
		                        </div>
		                        <?php
		                        if(isset($_REQUEST['message'])){ ?>
		                        <div class="alert alert-info alert-dismissible">
								    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
								    <?php echo $_REQUEST['message']?>
								  </div>
		                        <?php
		                        }
		                        ?>
		                        <div class="login-form">
		                            <form action="process.php" method="post" enctype="multipart/form-data">
		                                <div class="form-group">
		                                    <label>First Name</label>
		                                    <input class="au-input au-input--full" type="text" name="first_name" placeholder="First Name" required>
		                                </div>
		                                <div class="form-group">
		                                    <label>Last Name</label>
		                                    <input class="au-input au-input--full" type="text" name="last_name" placeholder="Last Name" required>
		                                </div>
		                                <div class="form-group">
		                                    <label>Email Address</label>
		                                    <input class="au-input au-input--full" type="email" name="email" placeholder="Email" required onblur="checkEmail(this)">
		                                     <span id="alert" class="badge badge-info"></span>
		                                </div>
		                                <div class="form-group">
		                                	<label>Gender</label>
		                                	<div class="form-check">
											  <input class="form-check-input" type="radio" name="gender" required value="Male"> Male
											  <input class="form-check-input" type="radio" name="gender" value="Female"> Female
											</div>
		                                </div>
		                                <div class="form-group">
		                                    <label>Profile Picture</label>
		                                    <input class="au-input au-input--full" type="file" name="profile_picture" required>
		                                </div>
		                                <div class="form-group">
		                                    <label>Password</label>
		                                    <input class="au-input au-input--full" type="password" name="password" placeholder="Password" required>
		                                </div>
		                                <br>
		                                <input class="au-btn au-btn--block au-btn--green m-b-20" type="submit" name="register" value="register">   
		                            </form>
		                            <div class="register-link">
		                                <p>
		                                    Already have account?
		                                    <a href="index.php">Sign In</a>
		                                </p>
		                            </div>
		                        </div>
		                    </div>
		                </div>
		            </div>
		        </div>
		    </div>
	
	<?php
	 } 
	public function user_body($user){
	//echo $user['user']['first_name']; ?>
		<body class="animsition">
    <div class="page-wrapper">     
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="#">
                    <img src="../images/icon/dashboard.png" alt="Dashboard" />
                </a>
            </div>
            
        </aside>
        <div class="page-container">
            <header class="header-desktop">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <div class="header-button">
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                            <img src="../<?php echo $user['user']['profile_picture']?>" alt="John Doe" />
                                        </div>
                                        <div class="content">
                                            <a href="edit_profile.php"><?php echo $user['user']['first_name']." ".$user['user']['last_name']?></a>
                                            <a href="../logout.php" >Logout</a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="au-card au-card--no-shadow au-card--no-pad m-b-40">
                                    <div class="au-card-title" style="background-image:url('images/bg-title-01.jpg');">
                                        <div class="bg-overlay bg-overlay--blue"></div>
                                        <h3>
                                            <i class="zmdi zmdi-account-calendar"></i><?php echo date("Y/m/d")?></h3>
                                        
                                    </div>
                                    <?php
		                        if(isset($_REQUEST['message'])){ ?>
		                        <div class="alert alert-info alert-dismissible">
								    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
								    <?php echo $_REQUEST['message']?>
								  </div>
		                        <?php
		                        }
		                        ?>
                                    <div class="au-task js-list-load">
                                       
                                        <div class="au-task-list js-scrollbar3">   
                                            <a href="process.php?action=attendance">
                                            	<div class="au-task__footer">
                                            <button class="au-btn au-btn-load js-load-btn">Place Attendance</button>
                                            </a>
                                        </div>
                                            <div class="au-task__footer">
                                            <a href="application.php">
                                            	<button class="au-btn au-btn-load js-load-btn">Place Application</button>
                                            </a>
                                        </div>
                                            <div class="au-task__footer">
                                            <a href="view_data.php">
                                            	<button class="au-btn au-btn-load js-load-btn">View Attendance</button>
                                            </a>
                                        </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


	<?php
	}

	public function apllication_body($user){
	//echo $user['user']['first_name']; ?>
		<body class="animsition">
    <div class="page-wrapper">     
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="#">
                    <img src="../images/icon/dashboard.png" alt="Dashboard" />
                </a>
            </div>
            
        </aside>
        <div class="page-container">
            <header class="header-desktop">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <div class="header-button">
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                            <img src="../<?php echo $user['user']['profile_picture']?>" alt="John Doe" />
                                        </div>
                                        <div class="content">
                                            <a href="edit_profile.php"><?php echo $user['user']['first_name']." ".$user['user']['last_name']?></a>
                                            <a href="../logout.php" >Logout</a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="au-card au-card--no-shadow au-card--no-pad m-b-40">
                                    <div class="au-card-title" style="background-image:url('images/bg-title-01.jpg');">
                                        <div class="bg-overlay bg-overlay--blue"></div>
                                        <h3>
                                            <i class="zmdi zmdi-account-calendar"></i><?php echo date("Y/m/d")?></h3><br>
                                        <h3>
                                            <i class="zmdi zmdi-account-calendar"></i><a href="dashboard.php" style="color: white"><button> Back to Dashboard</button></a></h3>
                                    </div>
                                    <?php
		                        if(isset($_REQUEST['message'])){ ?>
		                        <div class="alert alert-info alert-dismissible">
								    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
								    <?php echo $_REQUEST['message']?>
								  </div>
		                        <?php
		                        }
		                        ?>
                                    <div class="au-task js-list-load">
                                        <div class="au-task__footer">
                                           <form action="process.php" method="post">
		                                <div class="form-group">
		                                    <label>Application Title</label>
		                                    <input class="au-input au-input--full" type="text" name="application_title" placeholder="Application Title" required>
		                                </div>
		                                <div class="form-group">
		                                    <label>Application Description</label>
		                                    <textarea class="au-input au-input--full" name="application_description"></textarea>
		                                </div>
		                                <br>
		                                <input class="au-btn au-btn--block au-btn--green m-b-20" type="submit" value="Submit application" name="submit_application">
		                                
		                            </form> 
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


	<?php
	}
	public function edit_profile_body($user){
	//echo $user['user']['first_name']; ?>
		<body class="animsition">
    <div class="page-wrapper">     
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="#">
                    <img src="../images/icon/dashboard.png" alt="Dashboard" />
                </a>
            </div>
            
        </aside>
        <div class="page-container">
            <header class="header-desktop">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <div class="header-button">
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                            <img src="../<?php echo $user['user']['profile_picture']?>" alt="John Doe" />
                                        </div>
                                        <div class="content">
                                            <a href="edit_profile.php"><?php echo $user['user']['first_name']." ".$user['user']['last_name']?></a>
                                            <a href="../logout.php" >Logout</a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="au-card au-card--no-shadow au-card--no-pad m-b-40">
                                    <div class="au-card-title" style="background-image:url('images/bg-title-01.jpg');">
                                        <div class="bg-overlay bg-overlay--blue"></div>
                                        <h3>
                                            <i class="zmdi zmdi-account-calendar"></i><?php echo date("Y/m/d")?></h3><br>
                                        <h3>
                                            <i class="zmdi zmdi-account-calendar"></i><a href="dashboard.php" style="color: white"><button> Back to Dashboard</button></a></h3>
                                    </div>
                                    <?php
		                        if(isset($_REQUEST['message'])){ ?>
		                        <div class="alert alert-info alert-dismissible">
								    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
								    <?php echo $_REQUEST['message']?>
								  </div>
		                        <?php
		                        }
		                        ?>
                                    <div class="au-task js-list-load">
                                        <div class="au-task__footer" style="    text-align: -webkit-center;
}">
                                        	<img class="img-responsive" src="../<?php echo $user['user']['profile_picture']?>" alt="Chania" width="200" height="auto">
                                           <form action="process.php" method="post" enctype="multipart/form-data">
		                                <div class="form-group">
		                                    <label>Upload Profile</label>
		                                    <input class="au-input au-input--full" type="file" name="profile_picture" placeholder="" required>
		                                </div>
		                                
		                                <br>
		                                <input class="au-btn au-btn--block au-btn--green m-b-20" type="submit" value="Update Profile" name="update_profile">
		                                
		                            </form> 
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


	<?php
	}
	public function view_data_body($user,$result){
			
	//echo $user['user']['first_name']; ?>
		<body class="animsition">
    <div class="page-wrapper">     
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="#">
                    <img src="../images/icon/dashboard.png" alt="Dashboard" />
                </a>
            </div>
            
        </aside>
        <div class="page-container">
            <header class="header-desktop">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <div class="header-button">
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                            <img src="../<?php echo $user['user']['profile_picture']?>" alt="John Doe" />
                                        </div>
                                        <div class="content">
                                            <a href="edit_profile.php"><?php echo $user['user']['first_name']." ".$user['user']['last_name']?></a>
                                            <a href="../logout.php" >Logout</a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="au-card au-card--no-shadow au-card--no-pad m-b-40">
                                    <div class="au-card-title" style="background-image:url('images/bg-title-01.jpg');">
                                        <div class="bg-overlay bg-overlay--blue"></div>
                                        <h3>
                                            <i class="zmdi zmdi-account-calendar"></i><?php echo date("Y/m/d")?></h3><br>
                                        <h3>
                                            <i class="zmdi zmdi-account-calendar"></i><a href="dashboard.php" style="color: white"><button> Back to Dashboard</button></a></h3>
                                    </div>
                                    <?php
		                        if(isset($_REQUEST['message'])){ ?>
		                        <div class="alert alert-info alert-dismissible">
								    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
								    <?php echo $_REQUEST['message']?>
								  </div>
		                        <?php
		                        }
		                        ?>
                                    <div class="au-task js-list-load">
                                        <table cellspacing="5" cellpadding="5" border="0">
        <tbody><tr>
            <td>Minimum date:</td>
            <td><input type="text" id="min" name="min"></td>
        </tr>
        <tr>
            <td>Maximum date:</td>
            <td><input type="text" id="max" name="max"></td>
        </tr>
    </tbody></table>
    <table id="example" class="display nowrap" style="width:100%">
        <thead>
            <tr>
                <th>Attendance Status</th>
                <th>Attendance Date</th>
                
            </tr>
        </thead>
        <tbody>
        	<?php
        	while ($user_data = mysqli_fetch_assoc($result)) { ?>
        	<tr>
                <td><?php echo $user_data['a_status_name'] ?></td>
                <td><?php echo $user_data['attendance_date'] ?></td>
                
            </tr>
        	<?php	
        	}

        	?>
            
            
        </tfoot>
    </table>
		                                
		                                
		                               
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	<?php
	}
	public function view_Admin_body($user,$result,$statuses,$activity_log){
			
	//echo $user['user']['first_name']; ?>
		<body class="animsition">
    <div class="page-wrapper">     
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="dashboard.php">
                    <img src="../images/icon/dashboard.png" alt="Dashboard" />
                </a>
            </div>

            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li class="has-sub">
                            
                        <li>
                            <a href="reports.php">
                                <i class="fas fa-chart-bar"></i>Reports</a>
                        </li>
                        <li>
                            <a href="applications.php">
                                <i class="fas fa-table"></i>Applications</a>
                        </li>
                        <li>
                            <a href="grades.php">
                                <i class="far fa-check-square"></i>Grades</a>
                        </li>
                        
                    </ul>
                    <h3>Active Users</h3>
                    <ul>
                    	<?php while ($active = mysqli_fetch_assoc($activity_log) ) { ?>
                    		<li><?php echo $active['first_name']." ".$active['last_name']." Email : ".$active['email']." Time : ".$active['login_time'] ?></li>
                    		
                    	<?php } ?>
                    </ul>
                </nav>
            </div>
        </aside>
        <div class="page-container">
            <header class="header-desktop">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <div class="header-button">
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                            <img src="../<?php echo $user['user']['profile_picture']?>" alt="John Doe" />
                                        </div>
                                        <div class="content">
                                            <a href="edit_profile.php"><?php echo $user['user']['first_name']." ".$user['user']['last_name']?></a>
                                            <a href="../logout.php" >Logout</a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="au-card au-card--no-shadow au-card--no-pad m-b-40">
                                    <div class="au-card-title" style="background-image:url('images/bg-title-01.jpg');">
                                        <div class="bg-overlay bg-overlay--blue"></div>
                                        <h3>
                                            <i class="zmdi zmdi-account-calendar"></i><?php echo date("Y/m/d")?></h3><br>
                                        <h3>
                                            <i class="zmdi zmdi-account-calendar"></i><a href="dashboard.php" style="color: white"><button> Back to Dashboard</button></a></h3>
                                    </div>
                                    <?php
		                        if(isset($_REQUEST['message'])){ ?>
		                        <div class="alert alert-info alert-dismissible">
								    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
								    <?php echo $_REQUEST['message']?>
								  </div>
		                        <?php
		                        }
		                        ?>
                                    <div class="au-task js-list-load">
                                        <table cellspacing="5" cellpadding="5" border="0">
        <tbody><tr>
            <td>Minimum date:</td>
            <td><input type="text" id="min" name="min"></td>
        </tr>
        <tr>
            <td>Maximum date:</td>
            <td><input type="text" id="max" name="max"></td>
        </tr>
    </tbody></table>
    <table id="example" class="display nowrap" style="width:100%">
        <thead>
            <tr>
            	<th>User Name</th>
                <th>Email</th>
                
                <th>Attendance Date</th>
                <th>Attendance Status</th>
                
            </tr>
        </thead>
        <tbody>
        	<?php
        	while ($user_data = mysqli_fetch_assoc($result)) { ?>
        	<tr>
        		<td><?php echo $user_data['first_name']." ".$user_data['last_name'] ?></td>
                <td><?php echo $user_data['email'] ?></td>
                
                <td><?php echo $user_data['attendance_date'] ?></td>
                
                <td><select class="form-select form-control" aria-label="Default select example" onchange="update_status(this,<?php echo $user_data['user_id']?>,<?php echo $user_data['attendance_date']?>)">
                	<?php 
                	if ($user_data['a_status_id'] == 1) { ?>
                		<option selected value="1">Present</option>
                		<option value="2">Absent</option>
                		<option value="3">Leave</option>
                	<?php
                		
                	}elseif($user_data['a_status_id'] == 2){ ?>
                		<option selected value="2">Absent</option>
                		<option value="1">Present</option>
                		<option value="3">Leave</option>
                	<?php

                	}elseif ($user_data['a_status_id'] == 3) { ?>
                		<option selected value="3">Leave</option>
                		<option value="2">Absent</option>
                		<option value="1">Present</option>
                		
                	<?php
                	}
                	?>
					
				
					  
					
					
					</select>
				</td>
                
            </tr>
        	<?php	
        	}

        	?>
            
            
        </tfoot>
    </table>
		                                
		                                
		                               
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	<?php
	}

	public function applications_body($user,$result){
			
	//echo $user['user']['first_name']; ?>
		<body class="animsition">
    <div class="page-wrapper">     
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="dashboard.php">
                    <img src="../images/icon/dashboard.png" alt="Dashboard" />
                </a>
            </div>

            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li class="has-sub">
                            
                        <li>
                            <a href="reports.php">
                                <i class="fas fa-chart-bar"></i>Reports</a>
                        </li>
                        <li>
                            <a href="applications.php">
                                <i class="fas fa-table"></i>Applications</a>
                        </li>
                        <li>
                            <a href="grades.php">
                                <i class="far fa-check-square"></i>Grades</a>
                        </li>
                        
                    </ul>
                </nav>
            </div>
        </aside>
        <div class="page-container">
            <header class="header-desktop">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <div class="header-button">
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                            <img src="../<?php echo $user['user']['profile_picture']?>" alt="John Doe" />
                                        </div>
                                        <div class="content">
                                            <a href="edit_profile.php"><?php echo $user['user']['first_name']." ".$user['user']['last_name']?></a>
                                            <a href="../logout.php" >Logout</a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="au-card au-card--no-shadow au-card--no-pad m-b-40">
                                    <div class="au-card-title" style="background-image:url('images/bg-title-01.jpg');">
                                        <div class="bg-overlay bg-overlay--blue"></div>
                                        <h3>
                                            <i class="zmdi zmdi-account-calendar"></i><?php echo date("Y/m/d")?></h3><br>
                                        <h3>
                                            <i class="zmdi zmdi-account-calendar"></i><a href="dashboard.php" style="color: white"><button> Back to Dashboard</button></a></h3>
                                    </div>
                                    <?php
		                        if(isset($_REQUEST['message'])){ ?>
		                        <div class="alert alert-info alert-dismissible">
								    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
								    <?php echo $_REQUEST['message']?>
								  </div>
		                        <?php
		                        }
		                        ?>
                                    <div class="au-task js-list-load">
                                        <table cellspacing="5" cellpadding="5" border="0">
        <tbody><tr>
            <td>Minimum date:</td>
            <td><input type="text" id="min" name="min"></td>
        </tr>
        <tr>
            <td>Maximum date:</td>
            <td><input type="text" id="max" name="max"></td>
        </tr>
    </tbody></table>
    <table id="example" class="display nowrap" style="width:100%">
        <thead>
            <tr>
            	<th>User Id</th>
            	<th>User Name</th>
                <th>Email</th>
                <th>Application Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        	<?php
        	while ($user_data = mysqli_fetch_assoc($result)) { ?>
        	<tr>
        		<td><?php echo $user_data['user_id'] ?></td>
        		<td><?php echo $user_data['first_name']." ".$user_data['last_name'] ?></td>
                <td><?php echo $user_data['email'] ?></td>
                
                <td><?php echo $user_data['created_at'] ?></td>
                
                <td>
					<a href="process.php?action=approve&user_id=<?php echo $user_data['user_id'] ?>&created_at=<?php echo $user_data['created_at'] ?>">Approve</a> | <a href="view_application.php?action=view_application&user_id=<?php echo $user_data['user_id'] ?>&created_at=<?php echo $user_data['created_at'] ?>"> View</a>
				</td>
                
            </tr>
        	<?php	
        	}

        	?>
            
            
        </tfoot>
    </table>
		                                
		                                
		                               
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	<?php
	}
	public function view_application_body($user,$result){
			
	//echo $user['user']['first_name']; ?>
		<body class="animsition">
    <div class="page-wrapper">     
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="dashboard.php">
                    <img src="../images/icon/dashboard.png" alt="Dashboard" />
                </a>
            </div>

            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li class="has-sub">
                            
                        <li>
                            <a href="reports.php">
                                <i class="fas fa-chart-bar"></i>Reports</a>
                        </li>
                        <li>
                            <a href="applications.php">
                                <i class="fas fa-table"></i>Applications</a>
                        </li>
                        <li>
                            <a href="grades.php">
                                <i class="far fa-check-square"></i>Grades</a>
                        </li>
                        
                    </ul>
                </nav>
            </div>
        </aside>
        <div class="page-container">
            <header class="header-desktop">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <div class="header-button">
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                            <img src="../<?php echo $user['user']['profile_picture']?>" alt="John Doe" />
                                        </div>
                                        <div class="content">
                                            <a href="edit_profile.php"><?php echo $user['user']['first_name']." ".$user['user']['last_name']?></a>
                                            <a href="../logout.php" >Logout</a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="au-card au-card--no-shadow au-card--no-pad m-b-40">
                                    <div class="au-card-title" style="background-image:url('images/bg-title-01.jpg');">
                                        <div class="bg-overlay bg-overlay--blue"></div>
                                        <h3>
                                            <i class="zmdi zmdi-account-calendar"></i><?php echo date("Y/m/d")?></h3><br>
                                        <h3>
                                            <i class="zmdi zmdi-account-calendar"></i><a href="applications.php" style="color: white"><button> Back to Applications</button></a></h3>
                                    </div>
                                    <?php
		                        if(isset($_REQUEST['message'])){ ?>
		                        <div class="alert alert-info alert-dismissible">
								    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
								    <?php echo $_REQUEST['message']?>
								  </div>
		                        <?php
		                        }
		                        $application = mysqli_fetch_assoc($result);
		                        ?>
                                    <div class="au-task js-list-load">
                                        	<h1>Tittle : <?php echo $application['application_title'] ?> </h1>
                                        	<p>Description : <?php echo $application['application_description'] ?></p>
		                                
		                                
		                               
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	<?php
	}

	public function report_body($user,$users){
			
	//echo $user['user']['first_name']; ?>
		<body class="animsition">
    <div class="page-wrapper">     
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="dashboard.php">
                    <img src="../images/icon/dashboard.png" alt="Dashboard" />
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li class="has-sub">
                            
                        <li>
                            <a href="reports.php">
                                <i class="fas fa-chart-bar"></i>Reports</a>
                        </li>
                        <li>
                            <a href="applications.php">
                                <i class="fas fa-table"></i>Applications</a>
                        </li>
                        <li>
                            <a href="grades.php">
                                <i class="far fa-check-square"></i>Grades</a>
                        </li>
                        
                    </ul>
                </nav>
            </div>
            
        </aside>
        <div class="page-container">
            <header class="header-desktop">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <div class="header-button">
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                            <img src="../<?php echo $user['user']['profile_picture']?>" alt="John Doe" />
                                        </div>
                                        <div class="content">
                                            <a href="edit_profile.php"><?php echo $user['user']['first_name']." ".$user['user']['last_name']?></a>
                                            <a href="../logout.php" >Logout</a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="au-card au-card--no-shadow au-card--no-pad m-b-40">
                                    <div class="au-card-title" style="background-image:url('images/bg-title-01.jpg');">
                                        <div class="bg-overlay bg-overlay--blue"></div>
                                        <h3>
                                            <i class="zmdi zmdi-account-calendar"></i><?php echo date("Y/m/d")?></h3><br>
                                        <h3>
                                            <i class="zmdi zmdi-account-calendar"></i><a href="dashboard.php" style="color: white"><button> Back to Dashboard</button></a></h3>
                                    </div>
                                    <?php
		                        if(isset($_REQUEST['message'])){ ?>
		                        <div class="alert alert-info alert-dismissible">
								    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
								    <?php echo $_REQUEST['message']?>
								  </div>
		                        <?php
		                        }
		                        ?>
                                    
                                 
		                                <div class="au-task js-list-load">
                                        <div class="au-task__footer">
                                        	<h2>Perticular User Report</h2>
                                        	<hr>
                                           <form action="generate_user_report.php" method="post">

		                                <div class="form-group">
		                                    <label>Select Start Date</label>
		                                    <input class="au-input au-input--full" type="date" name="start_date" required>
		                                </div>
		                                <div class="form-group">
		                                    <label>Select End Date</label>
		                                    <input class="au-input au-input--full" type="date" name="end_date" required>
		                                </div>
		                                <div class="form-group">
		                                    <label>Select User</label>
		                                    <select class="form-select form-control" aria-label="Default select example" name="user_id">
											  <option selected disabled>Select User</option>
											  <?php
											  while ($data = mysqli_fetch_assoc($users)) {?>
											  		<option value="<?php echo $data['user_id']?>"><?php echo $data['email']?></option>
											  <?php
											  
											  }
											  ?>
											  
											  
											</select>
		                                </div>
		                                
		                                
		                                <br>
		                                <input style="background-color: rgba(49, 89, 253, 0.9)" class="au-btn au-btn--block au-btn--green m-b-20" type="submit" value="Generate" name="generate_report">
		                                
		                            </form> 
                                        </div>
                                        </div>
                                    <div class="au-task js-list-load">
                                        <div class="au-task__footer">
                                        	<h2>Users Report</h2>
                                        	<hr>
                                           <form action="generate_users_report.php" method="post">

		                                <div class="form-group">
		                                    <label>Select Start Date</label>
		                                    <input class="au-input au-input--full" type="date" name="start_date" required>
		                                </div>
		                                <div class="form-group">
		                                    <label>Select End Date</label>
		                                    <input class="au-input au-input--full" type="date" name="end_date" required>
		                                </div>
		                                
		                                
		                                
		                                <br>
		                                <input style="background-color: rgba(49, 89, 253, 0.9)" class="au-btn au-btn--block au-btn--green m-b-20" type="submit" value="generate_all_report" name="generate_all_report">
		                                
		                            </form> 
                                        </div>
                                        </div>
		                               
                                        
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	<?php
	}

	
}



?>