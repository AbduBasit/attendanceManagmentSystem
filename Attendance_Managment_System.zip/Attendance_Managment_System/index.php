<?php
session_start();
if(isset($_SESSION['user'])){
	header('location:logout.php');
}
require_once('includes/general.php');
require_once('includes/database.php');
$database = new DATABASE();
date_default_timezone_set('Asia/Karachi');
$date = date("Y-m-d");
$result = $database->check_date($date);
$dateCheck = date('l', strtotime(date('y/m/d')));
if ($dateCheck != 'Sunday') {
	if (!$result->num_rows) {
	$users = $database->get_all_users(); 
		for($i = 1; $i<=$users->num_rows; $i++){
			$user = mysqli_fetch_assoc($users);
			$database->place_attendance($user['user_id'],$date);
		}
	//print_r($users->num_rows);
    }
}


$general = new GENERAL_HTML();
$general->header('Login','css/theme.css');

$general->login_page();
$general->footer();

?>