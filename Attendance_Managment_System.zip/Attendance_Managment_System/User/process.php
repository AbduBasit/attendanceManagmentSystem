<?php
session_start();
require_once('../includes/database.php');
$database = new DATABASE();
date_default_timezone_set('Asia/Karachi');
if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'attendance') {
	$date = date("Y-m-d");
	$check = $database->check_attendance($_SESSION['user']['user_id'],$date);
	if($check->num_rows){
		header('location:dashboard.php?message=Attendance Already Placed');
	}else{
		$result = $database->update_attendance($_SESSION['user']['user_id'],$date);
		if ($result) {
			header('location:dashboard.php?message=Attendance Placed Successfully');
		}else{
			header('location:dashboard.php?message=Attendance not Placed Successfully');
		}

	}
}
if (isset($_REQUEST['submit_application'])) {
	extract($_POST);
	$date = date("Y-m-d");
	$result = $database->save_application($application_title,$application_description,$_SESSION['user']['user_id'],$date);
	if($result){
			header('location:application.php?message=Application Placed Successfully');
		}else{
			header('location:application.php?message=Application not Placed Successfully');
		}
}
if (isset($_POST['update_profile'])) {
	print_r($_FILES);
	extract($_FILES);
	$file_name = "images/".$profile_picture['name'];
	if(move_uploaded_file($profile_picture['tmp_name'],"../images/".$profile_picture['name'])){
		
		$result = $database->update_user_profile($_SESSION['user']['user_id'],$file_name);
	if($result){
		$result1 = $database->user_check($_SESSION['user']['email'], $_SESSION['user']['password']);
		$_SESSION['user'] = mysqli_fetch_assoc($result1);
		header('location:edit_profile.php?message=Profile Updated Successfully');
	}else{
		header('location:register.php?message=Profile not Updated Successfully');
	}

	}
}



?>