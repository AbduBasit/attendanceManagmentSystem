<?php
session_start();
if(!isset($_SESSION['user']) && $_SESSION['user']['role_id'] != 1){
    header('location:../login.php?message= Please Login First');
}
require_once('../includes/general.php');
require_once('../includes/database.php');
$general = new GENERAL_HTML();
$database = new DATABASE();
$general->header('Dashboard','../css/theme.css');
$result = $database->get_user_data($_SESSION['user']['user_id']);
//print_r($_SESSION);
$general->view_data_body($_SESSION,$result);
$general->footer();
?>
