function checkEmail(email){
	//console.log(email.value);
	var email = email.value;
	ajaxRequest     = null;
    if(window.XMLHttpRequest){
        ajaxRequest = new XMLHttpRequest();
    }else{
        ajaxRequest = new ActiveXObject("microsoft.XMLHTTP");
    }
    ajaxRequest.open("GET", "process.php?action=checkEmail&email= '"+email+"' ");
    ajaxRequest.send();
    ajaxRequest.onreadystatechange = function(){
        if(ajaxRequest.readyState == 4 && ajaxRequest.status == 200){
            //console.log(ajaxRequest.readyState);
            if(ajaxRequest.responseText == "true"){
            	document.getElementById("alert").innerHTML = "Email Already Registered";	
            }
            //console.log(ajaxRequest.responseText);
        }
    }
}
var minDate, maxDate;
 
// Custom filtering function which will search data in column four between two values
$.fn.dataTable.ext.search.push(
    function( settings, data, dataIndex ) {
        var min = minDate.val();
        var max = maxDate.val();
        var date = new Date( data[4] );
 
        if (
            ( min === null && max === null ) ||
            ( min === null && date <= max ) ||
            ( min <= date   && max === null ) ||
            ( min <= date   && date <= max )
        ) {
            return true;
        }
        return false;
    }
);
 
$(document).ready(function() {
    // Create date inputs
    minDate = new DateTime($('#min'), {
        format: 'MMMM Do YYYY'
    });
    maxDate = new DateTime($('#max'), {
        format: 'MMMM Do YYYY'
    });
 
    // DataTables initialisation
    var table = $('#example').DataTable();
 
    // Refilter the table
    $('#min, #max').on('change', function () {
        table.draw();
    });
});