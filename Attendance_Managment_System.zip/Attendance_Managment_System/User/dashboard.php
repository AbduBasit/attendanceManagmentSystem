
<?php
session_start();
if(!isset($_SESSION['user']) && $_SESSION['user']['role_id'] != 1){
    header('location:../login.php?message= Please Login First');
}
require_once('../includes/general.php');
$general = new GENERAL_HTML();
$general->header('Dashboard','../css/theme.css');
//print_r($_SESSION);
$general->user_body($_SESSION);
$general->footer();
?>
