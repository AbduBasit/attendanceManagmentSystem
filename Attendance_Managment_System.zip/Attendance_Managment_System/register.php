<?php
require_once('includes/general.php');
$general = new GENERAL_HTML();
$general->header('Register','css/theme.css');
$general->register_page();
$general->footer();
?>
