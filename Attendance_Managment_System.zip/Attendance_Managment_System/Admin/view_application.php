<?php
session_start();
if(!isset($_SESSION['user']) && $_SESSION['user']['role_id'] != 2){
    header('location:../login.php?message=Only Admin have Access');
}
if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'view_application') {
	require_once('../includes/general.php');
	require_once('../includes/database.php');
	$general = new GENERAL_HTML();
	$database = new DATABASE();
	$general->header('Dashboard','../css/theme.css');
	$result = $database->get_user_application($_REQUEST['user_id'],$_REQUEST['created_at']);
	$general->view_application_body($_SESSION,$result);
	$general->footer();
}

?>
