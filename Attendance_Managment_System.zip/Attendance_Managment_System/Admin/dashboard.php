<?php
session_start();
if(!isset($_SESSION['user']) && $_SESSION['user']['role_id'] != 2){
    header('location:../index.php?message=Only Admin have Access');
}
require_once('../includes/general.php');
require_once('../includes/database.php');
$general = new GENERAL_HTML();
$database = new DATABASE();
$general->header('Dashboard','../css/theme.css');
$result = $database->get_users_data();
$statuses = $database->get_status();
$activity_log = $database->get_activity_log();
$general->view_Admin_body($_SESSION,$result,$statuses,$activity_log);
$general->footer();
?>
