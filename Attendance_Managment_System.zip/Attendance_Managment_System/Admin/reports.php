<?php
session_start();
if(!isset($_SESSION['user']) && $_SESSION['user']['role_id'] != 2){
    header('location:../login.php?message=Only Admin have Access');
}
require_once('../includes/general.php');
require_once('../includes/database.php');
$general = new GENERAL_HTML();
$database = new DATABASE();
$general->header('Dashboard','../css/theme.css');
$result = $database->get_all_users();
$general->report_body($_SESSION,$result);
$general->footer();
?>
