<?php
session_start();
if(!isset($_SESSION['user']) && $_SESSION['user']['role_id'] != 2){
    header('location:../login.php?message=Only Admin have Access');
}
require_once('../includes/database.php');
$database = new DATABASE();
if (isset($_REQUEST['generate_report'])) {
	//print_r($_POST);
	extract($_POST);
	$user = $database->get_user_info($user_id);
	$user_info = mysqli_fetch_assoc($user); 
	$result = $database->user_report($start_date,$end_date,$user_id);
	$name = $user_info['email'].".xls";
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=$name");
	header('Cache-Control: no-cache, no-store, must-revalidate');
	header('Pragma: no-cache');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Attendance Report</title>
</head>
<body>
	<h1 align = "center">::.Attendance Report.::</h1>
	<h2 align = "center">::.<?php echo $user_info['first_name']." ".$user_info['last_name']." : ".$user_info['email'] ?>.::</h2>
	<hr />
	<table align = "center" border = "1">
		<tr>
			<td>Attendance Id</td>
			<td>Attendance Date</td>
			<td>Status</td>
		</tr>
		<?php while ($record = mysqli_fetch_assoc($result)) { ?>
		<tr>
			<td><?php echo $record['attendance_id']?></td>
			<td><?php echo $record['attendance_date']?></td>
			<td><?php echo $record['a_status_name']?></td>
		</tr>
		<?php
		}
		
		?>
	</table>
</body>
</html>

