<?php
session_start();
if(!isset($_SESSION['user']) && $_SESSION['user']['role_id'] != 2){
    header('location:../login.php?message=Only Admin have Access');
}
require_once('../includes/database.php');
$database = new DATABASE();
if (isset($_REQUEST['generate_all_report'])) {
	//print_r($_POST);
	extract($_POST);
	$result = $database->users_report($start_date,$end_date);
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=users_info.xls");
	header('Cache-Control: no-cache, no-store, must-revalidate');
	header('Pragma: no-cache');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Attendance Report</title>
</head>
<body>
	<h1 align = "center">::.Attendance Report.::</h1>
	<h2 align = "center">::.From : <?php echo $start_date." To : ".$end_date ?>.::</h2>
	<hr />
	<table align = "center" border = "1">
		<tr>
			<td>Attendance Id</td>
			<td>User Name</td>
			<td>User Email</td>
			<td>Attendance Date</td>
			<td>Status</td>
		</tr>
		<?php while ($record = mysqli_fetch_assoc($result)) { ?>
		<tr>
			<td><?php echo $record['attendance_id']?></td>
			<td><?php echo $record['first_name']." ".$record['last_name'] ?></td>
			<td><?php echo $record['email']?></td>
			<td><?php echo $record['attendance_date']?></td>
			<td><?php echo $record['a_status_name']?></td>
		</tr>
		<?php
		}
		
		?>
	</table>
</body>
</html>

