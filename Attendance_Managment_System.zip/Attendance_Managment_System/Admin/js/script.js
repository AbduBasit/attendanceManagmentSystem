function update_status(status,user_id,attendance_date){
    status_id = status.value;
    ajaxRequest     = null;
    if(window.XMLHttpRequest){
        ajaxRequest = new XMLHttpRequest();
    }else{
        ajaxRequest = new ActiveXObject("microsoft.XMLHTTP");
    }
    ajaxRequest.open("GET", "process.php?action=update_status&user_id="+user_id+"&status_id="+status_id+"&attendance_date"+attendance_date);
    ajaxRequest.send();
    ajaxRequest.onreadystatechange = function(){
        if(ajaxRequest.readyState == 4 && ajaxRequest.status == 200){
            //console.log(ajaxRequest.responseText);
             if(ajaxRequest.responseText == "true"){
                document.location.reload()
             }
            //console.log(ajaxRequest.responseText);
        }
    }
}
var minDate, maxDate;
 
// Custom filtering function which will search data in column four between two values
$.fn.dataTable.ext.search.push(
    function( settings, data, dataIndex ) {
        var min = minDate.val();
        var max = maxDate.val();
        var date = new Date( data[4] );
 
        if (
            ( min === null && max === null ) ||
            ( min === null && date <= max ) ||
            ( min <= date   && max === null ) ||
            ( min <= date   && date <= max )
        ) {
            return true;
        }
        return false;
    }
);
 
$(document).ready(function() {
    // Create date inputs
    minDate = new DateTime($('#min'), {
        format: 'MMMM Do YYYY'
    });
    maxDate = new DateTime($('#max'), {
        format: 'MMMM Do YYYY'
    });
 
    // DataTables initialisation
    var table = $('#example').DataTable();
 
    // Refilter the table
    $('#min, #max').on('change', function () {
        table.draw();
    });
});