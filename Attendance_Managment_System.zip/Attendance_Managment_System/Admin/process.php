<?php
session_start();
require_once('../includes/database.php');
$database = new DATABASE();
if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'update_status') {
	//print_r($_REQUEST);
	$result = $database->update_status($_REQUEST['user_id'],$_REQUEST['status_id'],$_REQUEST['attendance_date']);
	if ($result) {
		echo "true";
	}else{
		echo "false";
	}
	
}
if (isset($_REQUEST['submit_application'])) {
	extract($_POST);
	$date = date("Y-m-d");
	$result = $database->save_application($application_title,$application_description,$_SESSION['user']['user_id'],$date);
	if($result){
			header('location:application.php?message=Application Placed Successfully');
		}else{
			header('location:application.php?message=Application not Placed Successfully');
		}
}
if (isset($_POST['update_profile'])) {
	print_r($_FILES);
	extract($_FILES);
	$file_name = "images/".$profile_picture['name'];
	if(move_uploaded_file($profile_picture['tmp_name'],"../images/".$profile_picture['name'])){
		
		$result = $database->update_user_profile($_SESSION['user']['user_id'],$file_name);
	if($result){
		$result1 = $database->user_check($_SESSION['user']['email'], $_SESSION['user']['password']);
		$_SESSION['user'] = mysqli_fetch_assoc($result1);
		header('location:edit_profile.php?message=Profile Updated Successfully');
	}else{
		header('location:register.php?message=Profile not Updated Successfully');
	}

	}
}

if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'approve') {
	print_r($_REQUEST);
	$result = $database->approve_application($_REQUEST['user_id'],$_REQUEST['created_at']);
	if ($result) {
		$response = $database->update_user_attendance($_REQUEST['user_id'],$_REQUEST['created_at']);
		if ($response) {
			header('location:applications.php?message=Application Approved');
		}else{
			header('location:applications.php?message=Application Not Approved');
		}
	}

}



?>