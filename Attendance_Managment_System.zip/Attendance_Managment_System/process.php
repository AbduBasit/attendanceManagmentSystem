<?php
session_start();
require_once('includes/database.php');
$database = new DATABASE();
if(isset($_POST['register'])){
	//print_r($_POST);
	extract($_POST);
	extract($_FILES);
	//print_r($_FILES);
	$file_name = "images/".$profile_picture['name'];
	
	if(move_uploaded_file($profile_picture['tmp_name'],"images/".$profile_picture['name'])){
		$result = $database->register_user($first_name, $last_name, $email, $gender,$file_name, $password);
	if($result){
		header('location:register.php?message=Account Created Successfully');
	}else{
		header('location:register.php?message=Account Not Created Successfully');
	}

	}
	

}
if(isset($_POST['login'])){
	extract($_POST);
	$result = $database->user_check($email, $password);
	if($result->num_rows){
		$user = mysqli_fetch_assoc($result);
		if($user['role_id'] == 2){
			$_SESSION['user'] = $user;
			header('location:Admin/dashboard.php');	
		}else{
			$_SESSION['user'] = $user;
			$login_time = date("Y-m-d h:i:s");
			$response = $database->save_login_time($user['user_id'],$login_time);
			if ($response) {
				header('location:User/dashboard.php');
			}
			
		}
	}else{
		header('location:index.php?message=Invalid login credentials');
	}
}

if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'checkEmail'){
	//echo $_REQUEST['email'];
	$flag = NULL;  
	$result = $database->check_email($_REQUEST['email']);
	//print_r($result);
	if($result){
		$flag = "true";
	}else{
		$flag = "false";
	}
	echo $flag;

} 



?>