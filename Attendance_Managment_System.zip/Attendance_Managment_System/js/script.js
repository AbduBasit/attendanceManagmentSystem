function checkEmail(email){
	//console.log(email.value);
	var email = email.value;
	ajaxRequest     = null;
    if(window.XMLHttpRequest){
        ajaxRequest = new XMLHttpRequest();
    }else{
        ajaxRequest = new ActiveXObject("microsoft.XMLHTTP");
    }
    ajaxRequest.open("GET", "process.php?action=checkEmail&email= '"+email+"' ");
    ajaxRequest.send();
    ajaxRequest.onreadystatechange = function(){
        if(ajaxRequest.readyState == 4 && ajaxRequest.status == 200){
            //console.log(ajaxRequest.readyState);
            if(ajaxRequest.responseText == "true"){
            	document.getElementById("alert").innerHTML = "Email Already Registered";	
            }
            //console.log(ajaxRequest.responseText);
        }
    }
}