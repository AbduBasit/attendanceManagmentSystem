<?php
session_start();
require_once('includes/database.php');
$database = new DATABASE();
$logout_time = date("Y-m-d h:i:s");
$result = $database->save_logout_time($_SESSION['user']['user_id'],$logout_time);
if ($result) {
	session_destroy();
	header('location:index.php');
}

?>